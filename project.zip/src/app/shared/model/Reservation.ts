export interface Reservation {
    id: string;
    court: string;
    date: string;
    userEmail: string;
}