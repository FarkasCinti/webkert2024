
import { Reservation } from './Reservation';

export interface User {
  id: string;
  name: string;
  age: number;
  email: string;
  gender: string;
  newsletterAccepted: boolean;
  bookings: Reservation[]; 
}
