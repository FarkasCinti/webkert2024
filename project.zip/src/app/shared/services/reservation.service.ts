import { Injectable } from '@angular/core';
import {AngularFirestore} from '@angular/fire/compat/firestore';
import { Reservation } from '../model/Reservation';


@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  collectionName = 'Reservations';

  constructor(private afs: AngularFirestore) { }

  create(reservation: Reservation){
    reservation.id = this.afs.createId();
    return this.afs.collection<Reservation>(this.collectionName).doc(reservation.id).set(reservation);
  }

  getAll(){
    return this.afs.collection<Reservation>(this.collectionName).valueChanges();
  }

  delete(id: string){
    return this.afs.collection<Reservation>(this.collectionName).doc(id).delete;
  }

  update(reservation: Reservation){
    return this.afs.collection<Reservation>(this.collectionName).doc(reservation.id).set(reservation);
  }
}
