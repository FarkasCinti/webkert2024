import { Injectable } from '@angular/core';
import {AngularFirestore} from '@angular/fire/compat/firestore';
import { User } from '../model/User';
import { Reservation } from '../model/Reservation';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  collectionName = 'Users';

  constructor(private afs: AngularFirestore) { }

  create(user: User){
    return this.afs.collection<User>(this.collectionName).doc(user.id).set(user);
  }

  getAll(){
    return this.afs.collection<User>(this.collectionName).valueChanges();

  }

  getById(id: string){
    return this.afs.collection<User>(this.collectionName).doc(id).valueChanges();
  }

    getByEmail(email: string) {
    return this.afs.collection<User>(this.collectionName, ref => ref.where('email', '==', email)).valueChanges();
  }

  getBookingsByEmail(userEmail: string): Observable<Reservation[]> {
    return this.afs.collection<Reservation>('Reservations', ref => ref.where('userEmail', '==', userEmail).orderBy('date')).valueChanges();
  }
  

  update(user: User){
    return this.afs.collection<User>(this.collectionName).doc(user.id).set(user);
  }

  delete(id: string){
    return this.afs.collection<User>(this.collectionName).doc(id).delete();
  }

}
