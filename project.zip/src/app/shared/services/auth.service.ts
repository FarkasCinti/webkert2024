import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import firebase from 'firebase/compat/app'; // Importáljuk a firebase-t
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { UserService } from './user.service';
import { User } from '../model/User';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isLoggedInSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  currentUserEmail?: string | undefined;

  constructor(private auth: AngularFireAuth, private userService: UserService) {
    this.currentUserEmail = undefined;
    
    
    this.auth.authState.subscribe((user: firebase.User | null) => {
      if (user) {
        console.log('Bejelentkezett felhasználó:', user);
        if (user.email !== null) { 
          this.userService.getByEmail(user.email)
            .subscribe((users: User[]) => {
              if (users.length > 0) {
                this.currentUserEmail = users[0].email;
              } else {
                console.error('Felhasználó nem található az adatbázisban.');
              }
            });
        } else {
          console.error('A felhasználó e-mail címe null.');
        }
      } else {
        console.log('Nincs bejelentkezett felhasználó');
        this.currentUserEmail = undefined;
      }
      this.isLoggedInSubject.next(user !== null);
    });
  }

  login(email: string, password: string): Promise<void> {
    return this.auth.signInWithEmailAndPassword(email, password)
      .then(() => {
        const userData = { email: email, };
        localStorage.setItem('user', JSON.stringify(userData));
        localStorage.setItem('isLoggedIn', 'true');
        this.isLoggedInSubject.next(true); 
      })
      .catch(error => {
        console.error('Hiba a bejelentkezés során:', error);
        throw error; 
      });
  }

  register(email: string, password: string): Promise<string> {
    let newUserUid: string;

    return this.auth.createUserWithEmailAndPassword(email, password)
      .then(cred => {
        newUserUid = cred.user?.uid as string;

        return this.auth.signOut();
      })
      .then(() => {
        
        return newUserUid;
      });
  }

  logout(): Promise<void> {
    localStorage.removeItem('user');
    localStorage.removeItem('isLoggedIn');
    return this.auth.signOut().then(() => {
      this.isLoggedInSubject.next(false); 
    });
  }

  isLoggedIn(): Observable<boolean> {
    return this.isLoggedInSubject.asObservable();
  }

  getUser(): any {
    
    const userDataString = localStorage.getItem('user');
    return userDataString ? JSON.parse(userDataString) : null;
  }
}
