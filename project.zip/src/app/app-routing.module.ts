import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './pages/main/main.component';
import { GalleryComponent } from './pages/gallery/gallery.component';
import { BookingComponent } from './pages/booking/booking.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { AuthGuard } from './shared/services/auth.guard';

const routes: Routes = [
  { path: 'main', component: MainComponent },
  { path: 'gallery', component: GalleryComponent },
  { path: 'booking', component: BookingComponent, canActivate: [AuthGuard] }, // Levédve az AuthGuard-dal
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] }, // Levédve az AuthGuard-dal
  {path: 'login', component: LoginComponent},
  {path: 'registration', component: RegistrationComponent},
  { path: '', redirectTo: '/main', pathMatch: 'full' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
