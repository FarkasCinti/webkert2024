import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { AngularFireModule} from '@angular/fire/compat';
import { Validators, AbstractControl } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './pages/main/main.component';
import { GalleryComponent } from './pages/gallery/gallery.component';
import { BookingComponent } from './pages/booking/booking.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { MenuComponent } from './shared/menu/menu.component';
import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { getAuth, provideAuth } from '@angular/fire/auth';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { getStorage, provideStorage } from '@angular/fire/storage';
import { DateFormatPipe } from './shared/dateFormat.pipe';



const routes: Routes = [
  { path: 'main', component: MainComponent },
  { path: 'gallery', component: GalleryComponent },
  { path: 'booking', component: BookingComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'login', component: LoginComponent},
  { path: 'registration', component: RegistrationComponent},
  { path: '', redirectTo: '/main', pathMatch: 'full' } 
];

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    GalleryComponent,
    BookingComponent,
    ProfileComponent,
    MenuComponent,
    LoginComponent,
    RegistrationComponent,
    DateFormatPipe,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
    MatRadioModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatTableModule,
    MatSelectModule,
    AngularFireModule.initializeApp({"projectId":"webkert2024-31a61","appId":"1:704260555759:web:30f89a179d4c9439406c1a","storageBucket":"webkert2024-31a61.appspot.com","apiKey":"AIzaSyCzgZRx19KmFf5cC6ePM6qLQMhmhb20aNc","authDomain":"webkert2024-31a61.firebaseapp.com","messagingSenderId":"704260555759","measurementId":"G-NGW4DV3XN1"}),
    //provideFirebaseApp(() => initializeApp({"projectId":"webkert2024-31a61","appId":"1:704260555759:web:30f89a179d4c9439406c1a","storageBucket":"webkert2024-31a61.appspot.com","apiKey":"AIzaSyCzgZRx19KmFf5cC6ePM6qLQMhmhb20aNc","authDomain":"webkert2024-31a61.firebaseapp.com","messagingSenderId":"704260555759","measurementId":"G-NGW4DV3XN1"})),
    provideAuth(() => getAuth()),
    provideFirestore(() => getFirestore()),
    provideStorage(() => getStorage())
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
