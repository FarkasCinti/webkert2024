import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../shared/services/auth.service';
import { Router } from '@angular/router';
import { User } from '../../shared/model/User';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  name: string = '';
  age: number = 0;
  email: string = '';
  password: string = '';
  newsletterAccepted: boolean = false;
  gender: string = 'Nő'; 
  errorMessage: string = ''; 

  constructor(private authService: AuthService, private router: Router, private userService: UserService) {}

  onSubmit(form: NgForm) {
    this.authService.register(this.email, this.password)
      .then(userId => {
        console.log('Sikeres regisztráció, felhasználó azonosítója:', userId);
        const user: User = {
          name: this.name,
          age: this.age,
          email: this.email,
          newsletterAccepted: this.newsletterAccepted,
          gender: this.gender,
          id: userId,
          bookings: []
        
        }
        this.userService.create(user).then(_ => {
          console.log("Regisztráció sikeres");
          this.router.navigate(['/login']); 
        }).catch(error => {
          console.error(error);
        })
      })
      .catch(error => {
        console.error('Hiba a regisztráció során:', error);
        this.errorMessage = error.message;
      });
  }
}
