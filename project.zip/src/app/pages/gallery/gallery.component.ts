import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent {
  images: Image[] = [
    { src: '/assets/gallery1.jpg', alt: 'Image 1', title: 'Hangulat' },
    { src: '/assets/gallery2.jpg', alt: 'Image 2', title: 'Pályánk' },
    { src: '/assets/gallery3.jpg', alt: 'Image 3', title: 'Baráti társaság' }
  ];
}

export interface Image {
  src: string;
  alt: string;
  title: string;
}
