import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user.service';
import { User } from '../../shared/model/User';
import { AuthService } from '../../shared/services/auth.service';
import { Router } from '@angular/router';
import { Reservation } from '../../shared/model/Reservation';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
  user?: User = { id: '', name: '', age: 0, email: '', gender: '', newsletterAccepted: false, bookings: [] };


  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const userDataString = localStorage.getItem('user');
    if (userDataString) {
      const userData = JSON.parse(userDataString);
      if (userData && userData.email) {
        const userEmail = userData.email;
        this.userService.getByEmail(userEmail).subscribe(data => {
          if (data && data.length > 0) {
            this.user = data[0];
            this.user.bookings = []; 
            this.getBookings(userEmail);
          } else {
            console.error('User not found.');
          }
        }, (error: any) => {
          console.error(error);
        });
      } else {
        console.error('Invalid user data in local storage.');
      }
    } else {
      console.error('User data not found in local storage.');
    }
  }
  
  
  getBookings(userEmail: string) {
    this.userService.getBookingsByEmail(userEmail).subscribe((bookings: Reservation[]) => {
      console.log('Felhasználó foglalásai rendezve dátum szerint:', bookings);
      if (this.user) {
        this.user.bookings = bookings;
      }
    }, (error: any) => {
      console.error('Hiba történt a foglalások lekérése során:', error);
    });
  }
  
  

  updateProfile() {
    if (!this.user || !this.user.id) {
      console.error('User or user ID not found.');
      return;
    }
    
    this.user.name = 'Új név';
    this.user.age = 30;

    this.userService.update(this.user).then(() => {
      console.log('User data updated successfully.');
    }).catch(error => {
      console.error('Error updating user data:', error);
    });
  }

  async deleteProfile() {
    try {
      if (!this.user || !this.user.id) {
        console.error('Nem található felhasználó vagy azonosító.');
        return;
      }
      await this.userService.delete(this.user.id);
      console.log('Profil sikeresen törölve.');
      await this.authService.logout();
      console.log('Sikeres kijelentkezés profil törlése után.');
      this.router.navigate(['/login']);
    } catch (error) {
      console.error('Hiba történt a profil törlése közben:', error);
    }
}
}
