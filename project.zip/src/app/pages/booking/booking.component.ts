import { Component } from '@angular/core';
import { Reservation } from '../../shared/model/Reservation';
import { ReservationService } from '../../shared/services/reservation.service';
import { AuthService } from '../../shared/services/auth.service'; // AuthService importálása

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})

export class BookingComponent {
  courts = [
    { id: 1, name: 'Pálya 1' },
    { id: 2, name: 'Pálya 2' },
    { id: 3, name: 'Pálya 3' },
    { id: 4, name: 'Pálya 4' }
  ];

  availableTimes: { date: Date, time: string }[] = [];

  constructor(
    private reservationService: ReservationService,
    private authService: AuthService // AuthService injektálása
  ) {
    this.generateAvailableTimes();
    
  }

  selectedTimes: { [key: number]: Date } = {};

  generateAvailableTimes() {
    const currentDate = new Date(); // Az aktuális dátum
    for (let i = 0; i < 5; i++) { // Az aktuális naptól számítva a következő 5 nap
      const date = new Date(currentDate);
      date.setDate(date.getDate() + i);
      const dateString = this.formatDate(date); // Dátum formázása
      this.availableTimes.push({ date: date, time: dateString });
    }
  }

  formatDate(date: Date): string {
    // Dátum formázása pl. "YYYY-MM-DD"
    const year = date.getFullYear();
    const month = this.padZero(date.getMonth() + 1); // Hónapok 0-tól indulnak
    const day = this.padZero(date.getDate());
    return `${year}-${month}-${day}`;
  }

  padZero(num: number): string {
    // Szám formázása két számjegyűre
    return num < 10 ? `0${num}` : `${num}`;
  }

  requestBooking(courtId: number) {
    const selectedTime = this.selectedTimes[courtId];
    if (selectedTime) {
      const currentDate = new Date(); 
      if (selectedTime.getTime() >= currentDate.getTime()) { 
        console.log(`Foglalás: ${selectedTime} - Pálya: ${courtId}`);
  
        const currentUser = this.authService.getUser(); // Aktuális felhasználó lekérése
        if (currentUser && currentUser.email) { // Null ellenőrzés és e-mail ellenőrzés
          const reservation: Reservation = {
            id: '', 
            court: `Pálya ${courtId}`,
            date: selectedTime.toISOString(),
            userEmail: currentUser.email // Felhasználó e-mail címe hozzáadása a foglaláshoz
          };
  
          this.reservationService.create(reservation)
            .then(() => {
              console.log('Foglalás sikeresen létrehozva.');
            })
            .catch(error => {
              console.error('Hiba történt a foglalás létrehozása során:', error);
            });
        } else {
          console.error('Nem található aktuális felhasználó vagy e-mail cím.');
        }
      } else {
        console.log('Nem lehet foglalni lejárt időpontban.');
      }
    }
  }
  
  displayedColumns = ['name', 'time', 'book'];
}
