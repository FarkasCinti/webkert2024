import { Component } from '@angular/core';
import { NgForm } from '@angular/forms'; 
import { AuthService } from '../../shared/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService,private router: Router) {}

  onSubmit(form: NgForm) {
    
    this.authService.login(this.email, this.password)
      .then(() => {
        console.log('Sikeres bejelentkezés!');
        this.router.navigate(['/profile']);
      })
      .catch(error => {
        console.error('Hiba a bejelentkezés során:', error);
       
      });
}
}
